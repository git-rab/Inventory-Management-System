<?php 

 ?>

 <!DOCTYPE html>
 <html>


    <?php include('project/header.php'); ?>
    <?php include('project/footer.php'); ?>
    
 
 </html>